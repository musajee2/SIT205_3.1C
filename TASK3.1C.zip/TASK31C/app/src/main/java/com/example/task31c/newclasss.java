package com.example.task31c;

public class newclasss {
}
