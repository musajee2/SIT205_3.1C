package com.example.task31c;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class QuizActivity extends AppCompatActivity {
    private TextView questionTextView;
    private RadioGroup optionsRadioGroup;
    private Button submitButton;
    private TextView progressTextView;
    private List<Question> questions;
    private int currentQuestionIndex = 0;
    private int correctAnswers = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        questionTextView = findViewById(R.id.questionTextView);
        optionsRadioGroup = findViewById(R.id.optionsRadioGroup);
        submitButton = findViewById(R.id.submitButton);
        progressTextView = findViewById(R.id.progressTextView);
        questions = getQuestions();
        if (questions != null && !questions.isEmpty()) {
            Collections.shuffle(questions);
            displayQuestion(currentQuestionIndex);
        } else {
            Toast.makeText(this, "No questions available", Toast.LENGTH_SHORT).show();
            finish();
        }

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });
    }

    private void displayQuestion(int index) {
        int progress = currentQuestionIndex + 1;
        progressTextView.setText("Progress: " + progress + "/10");

        Question currentQuestion = questions.get(index);
        questionTextView.setText(currentQuestion.getQuestion());
        optionsRadioGroup.clearCheck();
        optionsRadioGroup.removeAllViews();

        List<String> options = currentQuestion.getOptions();
        Collections.shuffle(options);

        for (String option : options) {
            RadioButton radioButton = new RadioButton(this);
            radioButton.setText(option);
            optionsRadioGroup.addView(radioButton);
        }
    }

    private void checkAnswer() {
        int selectedOptionId = optionsRadioGroup.getCheckedRadioButtonId();
        if (selectedOptionId != -1) {
            RadioButton selectedRadioButton = findViewById(selectedOptionId);
            if (selectedRadioButton != null) {
                String selectedAnswer = selectedRadioButton.getText().toString();
                if (selectedAnswer.equals(questions.get(currentQuestionIndex).getCorrectAnswer())) {
                    //selectedRadioButton.setBackgroundColor(Color.GREEN);
                    correctAnswers++;
                }
                //selectedRadioButton.setBackgroundColor(Color.RED);
                currentQuestionIndex++;
                if (currentQuestionIndex < questions.size()) {
                    displayQuestion(currentQuestionIndex);
                } else {
                    showFinalScore();
                }
            } else {
                Toast.makeText(this, "Error: Selected radio button is null", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show();
        }
    }

    private void showFinalScore() {
        Intent intent = new Intent(QuizActivity.this, FinalScoreActivity.class);
        intent.putExtra("final_score", correctAnswers);
        startActivity(intent);
        finish();
    }

    private List<Question> getQuestions() {
        List<Question> questions = new ArrayList<>();
        questions.add(new Question("What country has the highest life expectancy?", "Hong Kong", "Hong Kong", "Rome", "Spanish", "Scurvy"));
        questions.add(new Question("Where would you be if you were standing on the Spanish Steps?", "Rome", "Hong Kong", "Rome", "Spanish", "Scurvy"));
        questions.add(new Question("Which language has the more native speakers: English or Spanish?", "Spanish", "Hong Kong", "Rome", "Spanish", "Scurvy"));
        questions.add(new Question("What is the most common surname in the United States?", "Smith", "Smith", "Rome", "Moseles", "Scurvy"));
        questions.add(new Question("What disease commonly spread on pirate ships?", "Scurvy", "Hong Kong", "Rome", "Spanish", "Scurvy"));
        questions.add(new Question("Who was the Ancient Greek God of the Sun?", "Apollo", "Apollo", "Zeus", "Micheal", "Lucifer"));
        questions.add(new Question("What was the name of the crime boss who was head of the feared Chicago Outfit?", "Al Capone", "Al Capone", "Pablo Escobar", "Lucifer", "Osama"));
        questions.add(new Question("What year was the United Nations established?", "1945", "1945", "1946", "1947", "1948"));
        questions.add(new Question("Who has won the most total Academy Awards?", "Walt Disney", "Walt Disney", "Rome", "Pixar", "United"));
        questions.add(new Question("What artist has the most streams on Spotify?", "Drake", "Post Malone", "Drake", "Rihana", "Miley Cyrus"));
        return questions;
    }
}
